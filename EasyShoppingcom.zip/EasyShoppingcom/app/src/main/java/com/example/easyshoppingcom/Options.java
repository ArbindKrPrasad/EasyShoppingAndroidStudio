package com.example.easyshoppingcom;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Options extends AppCompatActivity {
    int cart_count;
    Button count_btn, back_btn, contact_btn;
    TextView cart_tv, name_tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_options);
        count_btn = findViewById(R.id.button3);
        cart_tv = findViewById(R.id.textView3);
        count_btn.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                cart_tv.setText(getString(R.string.cart_count)+" "+cart_count);
            }
        });

        back_btn = findViewById(R.id.button5);
        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(i);
            }
        });

        contact_btn = findViewById(R.id.button4);
        contact_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ContextCompat.checkSelfPermission(Options.this, Manifest.permission.CALL_PHONE)!= PackageManager.PERMISSION_GRANTED){
                    ActivityCompat.requestPermissions(Options.this, new String[] { Manifest.permission.CALL_PHONE}, 1);
                } else{
                    Toast.makeText(Options.this, getString(R.string.call_customer), Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:"+("+919876543210")));
                    startActivity(intent);
                }
            }
        });

        name_tv = findViewById(R.id.textView);
        Bundle b = getIntent().getExtras();
        String name = b.getString("my_key");
        name_tv.setText(getString(R.string.welcome)+" "+name);


    }
    public void shop(View v){
        Intent i = new Intent(this, Products.class);
        startActivityForResult(i, 2);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==2&&RESULT_OK==resultCode){
            Bundle b = data.getExtras();
            cart_count= b.getInt("count");
        }
    }
}