package com.example.easyshoppingcom;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText fn, ln, phn, eml, pwd, cpwd;
    TextView warn;
    boolean  isEmailValid=false, isPwdvalid = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void sign_up(View v){
        fn=findViewById(R.id.editTextTextPersonName);
        ln=findViewById(R.id.editTextTextPersonName2);
        phn=findViewById(R.id.editTextPhone);
        eml=findViewById(R.id.editTextTextEmailAddress);
        pwd=findViewById(R.id.editTextTextPassword);
        cpwd=findViewById(R.id.editTextTextPassword2);
        warn=findViewById(R.id.textView4);

        String phn_no = phn.getText().toString();

        String email= eml.getText().toString();
        int at_pos = email.indexOf("@");
        int dot_pos = email.lastIndexOf(".");

        if(at_pos>4&&dot_pos-at_pos>2&&email.length()-dot_pos>2){
            isEmailValid = true;
        }
        else{
            isEmailValid=false;
        }

        String password = pwd.getText().toString();
        boolean isCapital=false;
        boolean isSymbol= false;
        String symbol = "@!#$%^&*()_+?/>.<";

        for(int i=0; i<password.length(); i++){
            char ch = password.charAt(i);
            if(Character.isUpperCase(ch)){
                isCapital = true;
            }
            String chstr = Character.toString(ch);
            if(symbol.contains(chstr)){
                isSymbol=true;
            }
        }

        if(isCapital&&isSymbol&&password.length()>5){
            isPwdvalid=true;
        } else{
            isPwdvalid=false;
        }

        String conf_password = cpwd.getText().toString();

        String first_name = fn.getText().toString();
        String last_name = ln.getText().toString();
        String full_name = first_name+" "+last_name;

        if(first_name.length()>0&&last_name.length()>0&&phn_no.length()==10&&isEmailValid&&isPwdvalid&&password.equals(conf_password)){
            Intent i = new Intent(MainActivity.this, Options.class);
            i.putExtra("my_key", full_name);
            startActivity(i);
        }
        else{
            if(first_name.length()==0){
                warn.setText(getString(R.string.provide_fname));
            }
            else if(last_name.length()==0){
                warn.setText(R.string.provide_lname);
            }
            else if(phn_no.length()==0){
                warn.setText(getString(R.string.provide_mobile_no));
            }
            else if(phn_no.length()!=10){
                warn.setText(getString(R.string.not_ten_digit));
            }
            else if(!isEmailValid){
                warn.setText(getString(R.string.invalid_email));
            }
            else if(!isPwdvalid){
                warn.setText(getString(R.string.pwd_not_valid));
            }
            else if(!password.equals(conf_password)){
                warn.setText(getString(R.string.password_not_match));
            }
            else{
                warn.setText("");
            }
        }
    }
}