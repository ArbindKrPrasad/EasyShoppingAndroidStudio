package com.example.easyshoppingcom;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;

public class Products extends AppCompatActivity {
    GridView gridView;
    boolean[] bool_arr = {false, false, false, false, false, false, false, false, false, false, false};
    int[] products ={R.drawable.item1,R.drawable.item2, R.drawable.item3, R.drawable.item4, R.drawable.item5, R.drawable.item6,
            R.drawable.item7, R.drawable.item8, R.drawable.item9, R.drawable.item10, R.drawable.item11};
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_products);

        gridView = findViewById(R.id.products_grid);
        gridView.setAdapter(new ImageAdapterGridView(this));
        gridView.setChoiceMode(GridView.CHOICE_MODE_MULTIPLE);

        btn = findViewById(R.id.button6);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int count = 0;
                for(int i=0; i<bool_arr.length; i++){
                    if(bool_arr[i]==true) count++;
                }
                Intent i = new Intent();
                i.putExtra("count", count);
                setResult(RESULT_OK,i);
                finish();
            }
        });


        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                System.out.println(position);
                if(bool_arr[position]==false){
                    bool_arr[position]=true;

                    Toast.makeText(Products.this, getString(R.string.added_to_cart), Toast.LENGTH_SHORT).show();
                }
                else{
                    bool_arr[position]= false;
                    Toast.makeText(Products.this, getString(R.string.item_removed), Toast.LENGTH_SHORT).show();
                }
                System.out.println(bool_arr[position]);

            }
        });


    }
    public class ImageAdapterGridView extends BaseAdapter {
        private Context mContext;
        public ImageAdapterGridView(Context c) {
            mContext = c;
        }
        public int getCount() {
            return products.length;
        }

        public Object getItem(int position) {
            return position;
        }

        public long getItemId(int position) {
            return 0;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            ImageView mImageView;

            if (convertView == null) {
                mImageView = new ImageView(mContext);
                mImageView.setLayoutParams(new GridView.LayoutParams(300, 300));
                mImageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                mImageView.setPadding(10, 20, 10, 20);
            } else {
                mImageView = (ImageView) convertView;
            }
            mImageView.setImageResource(products[position]);
            return mImageView;
        }
    }
}